package com.fesaragon.proyecto_iniciodesesion

class password {
    companion object {
        private const val DEFAULT_PASSWORD_LENGTH = 8

        fun generatePassword(length: Int = DEFAULT_PASSWORD_LENGTH): String {
            val allowedChars = "ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz0123456789"
            val random = java.util.Random()
            val password = StringBuilder(length)

            repeat(length) {
                val randomIndex = random.nextInt(allowedChars.length)
                password.append(allowedChars[randomIndex])
            }

            return password.toString()
        }
    }
}
