package com.fesaragon.proyecto_iniciodesesion.ui.theme

import android.content.Intent
import android.os.Bundle
import android.text.InputType
import android.widget.Button
import android.widget.EditText
import android.widget.LinearLayout
import android.widget.Toast
import androidx.appcompat.app.AppCompatActivity

class LoginActivity : AppCompatActivity() {
    private val registeredUsers = mutableMapOf<String, String>()

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)

        val layout = LinearLayout(this)
        layout.orientation = LinearLayout.VERTICAL

        val editTextEmail = EditText(this)
        editTextEmail.hint = "Email"
        editTextEmail.inputType = InputType.TYPE_TEXT_VARIATION_EMAIL_ADDRESS

        val editTextPassword = EditText(this)
        editTextPassword.hint = "Contraseña"
        editTextPassword.inputType = InputType.TYPE_TEXT_VARIATION_PASSWORD

        val buttonLogin = Button(this)
        buttonLogin.text = "Iniciar sesión"
        buttonLogin.setOnClickListener {
            val email = editTextEmail.text.toString()
            val password = editTextPassword.text.toString()
            simulateLogin(email, password)
        }

        // Agrega los elementos al layout
        layout.addView(editTextEmail)
        layout.addView(editTextPassword)
        layout.addView(buttonLogin)
        setContentView(layout)
    }

    private fun simulateLogin(email: String, password: String) {
        if (isValidEmail(email) && isValidPassword(password)) {
            if (registeredUsers.containsKey(email)) {
                Toast.makeText(this, "Este correo ya está registrado", Toast.LENGTH_SHORT).show()
            } else {
                registeredUsers[email] = password
                if (authenticateUser(email, password)) {
                    // Autenticación exitosa, redirige al usuario a la siguiente pantalla
                    // Por ejemplo:
                    val intent = Intent(this, HomeActivity::class.java)
                    startActivity(intent)
                } else {
                    Toast.makeText(this, "Error de autenticación. Inténtalo de nuevo.", Toast.LENGTH_SHORT).show()
                }
            }
        } else {
            Toast.makeText(this, "Correo o contraseña inválidos", Toast.LENGTH_SHORT).show()
        }
    }

    private fun isValidEmail(email: String): Boolean {
        // Implementa tu lógica de validación de correo electrónico aquí
        private fun isValidEmail(email: String): Boolean {
            // Verifica si el correo tiene un formato válido
            val emailPattern = "[a-zA-Z0-9._-]+@[a-z]+\\.+[a-z]+"
            return email.matches(emailPattern.toRegex())
        }
        return true
    }

    private fun isValidPassword(password: String): Boolean {
        // Implementa tu lógica de validación de contraseña aquí
        private fun isValidPassword(password: String): Boolean {
            val minLength = 8
            val hasUppercase = password.any { it.isUpperCase() }
            val hasLowercase = password.any { it.isLowerCase() }
            val hasDigit = password.any { it.isDigit() }
            return password.length >= minLength && hasUppercase && hasLowercase && hasDigit
        }
        return true
    }

    private fun authenticateUser(email: String, password: String): Boolean {
        // Aquí debes implementar la lógica de autenticación
        // Por ejemplo, consulta una base de datos real o compara con valores fijos
        // Devuelve true si la autenticación es exitosa, o false si no
        // Ejemplo: Verifica si el correo y la contraseña coinciden en valores fijos
        val validEmail = "usuario@example.com"
        val validPassword = "contraseña123"
        return email == validEmail && password == validPassword
    }
}

